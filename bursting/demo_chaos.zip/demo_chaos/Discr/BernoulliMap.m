function fx=BernoulliMap(x,rParam)
%rParam=1.99

fx=rem(rParam*x,1);
