function fx=tentmap(x,rParam)
%rParam=0.99

fx=rParam*(1-abs(1-2*x));
